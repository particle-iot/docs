## v1

### COMPATIBILTY

Must be built using device OS v4.0.2 or greater.

### FEATURES

- Basic support for 4-20mA, 0-10V, high voltage input, and relay features of IO expansion card.

### ENHANCEMENTS


### BUGFIXES
