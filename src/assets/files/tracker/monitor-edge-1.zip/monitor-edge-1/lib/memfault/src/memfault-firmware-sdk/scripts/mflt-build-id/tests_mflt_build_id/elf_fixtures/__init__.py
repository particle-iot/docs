#
# Copyright (c) Memfault, Inc.
# See License.txt for details
#

import os

ELF_FIXTURES_DIR = os.path.dirname(os.path.realpath(__file__))
