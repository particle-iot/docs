#include <functional>

#include "concurrent_hal.h"

os_result_t os_thread_exit(os_thread_t thread)
{
	return 0;
}
